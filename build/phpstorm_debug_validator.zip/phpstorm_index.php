<?php
require "phpstorm_debug_validator.phar";
